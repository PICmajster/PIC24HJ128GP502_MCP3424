/*****************************************************************************
  FileName:        main.c
  Processor:       PIC24HJ128GP502
  Compiler:        XC16 ver 1.30
******************************************************************************/

#include "xc.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h> /*dyrektywy uint8_t itp*/
#include <string.h>
#include <math.h>
#include "ustaw_zegar.h" /*tutaj m.in ustawione FCY*/
#include <libpic30.h> /*dostep do delay-i,musi byc po zaincludowaniu ustaw_zegar.h*/
#include "dogm204.h"
#include "i2c.h"

/*******************************************************************************
 DEKLARACJE FUNKCJI
 ******************************************************************************/
 void Set_MCP3424(void);
 int read_MCP3424(void);
 void InitTimer1(void);
/*******************************************************************************
 DEKLARACJE/DEFINICJE ZMIENNYCH
 ******************************************************************************/
#define AdressMCP3424 0x0 /*A0,A1 --> 00*/
volatile uint8_t Timer1_Programowy , Timer2_Programowy ;
float wynik, wynikTotal, wynikFraction;
int wynikADC;
char tablica[16];
int licznik;

int main(void) {
    ustaw_zegar(); /*odpalamy zegar wewnetrzny na ok 40MHz (39.61375 MHz)*/
    __delay_ms(50) ; /*stabilizacja napiec*/
    /*
    * wylaczamy ADC , wszystkie piny chcemy miec cyfrowe
    * pojedynczo piny analogowe wylaczamy w rejestrze AD1PCFGL 
    * Po resecie procka piny oznaczone ANx sa w trybie analogowych wejsc.
    */
      PMD1bits.AD1MD=1 ; /*wylaczamy ADC*/
      /* 
       * ustawiamy wszystkie piny analogowe (oznacznone ANx) jako cyfrowe
       * do zmiany mamy piny AN0-AN5 i AN9-AN12 co daje hex na 16 bitach = 0x1E3F
       */
    AD1PCFGL = 0x1E3F ;
    TRISAbits.TRISA1 = 0 ; /*RA1 jako wyjscie, tu mamy podpieta LED*/
    
    InitTimer1(); /*Timer 1 Init*/
    ustaw_I2C1(); /*I2C1 Init*/
    WlaczLCD();   /*LCD Init*/
    WpiszSwojeZnaki(); /*znak stopnia definjujemy*/
    Set_MCP3424(); /*konfiguracja przetwornika*/
    
    licznik = 0;     
    while (1) {
        /*w trybie 16 bitow mamy 1 probke po ok 66 ms (15SPS) (1000ms / 15) odczyt zrobimy co 70ms*/
        /*co 70ms wykonaj czynnosc*/
            if(!Timer1_Programowy) {
             Timer1_Programowy = 7 ; /*Timer1 sprzetowy x Timer1_Programowy = 10ms x 7 = 70ms*/
             if(licznik > 10) licznik = 0; /*10 x 70ms = 700ms*/
             wynikADC = read_MCP3424();/*pobieramy dane do zmiennej  celem dalszych przeksztalcen*/
             /*tutaj wstawi? trzeba jeszcze wykrywanie znaku temp. na podstawie ADC, 0st to 7999,75 dla tryby 16bit*/
             wynik = wynikADC; 
             wynik *= 204.8 ;
             wynik /= 32767.0 ;
             wynik -= 50.0 ;
             /*rozdziel wynik na czesc calkowita (wynikTotal) i ulamkowa (wynikFraction), przygotuj do wyswietlania na LCD*/
             wynikFraction = modff(wynik, &wynikTotal);/*operacja rodzielania na czesc calkowita i ulamkowa*/
             wynikFraction *= 10.0;  /*interesuje nas 1 cyfra czesci ulamkowej, przenosimy ja na czesc calkowita*/
             wynikFraction = floorf(wynikFraction);   /*wyodrebnij przeniesiona z czesci ulamkowej czesc calkowita*/
             wynikADC = (int)wynikTotal; 
             sprintf(tablica,"%i",wynikADC);  /*zmienna int konwertujemy na char i umieszczamy ja w tablicy*/
             /*dane mamy gotowe do wyswietlania*/
             /*wyswietlamy dane co ok 700ms, nie ma potrzeby szybciej*/
             if(++licznik == 10) {
             UstawKursorLCD(1,1);
             WyswietlLCD("Temperatura: ");
             WyswietlLCD(tablica); /*wyswietlamy czesc calkowita temperatury*/
             Wyslij_do_LCD(44); /*przecinek*/
             wynikADC = (int)wynikFraction; /*czesc ulamkowa (1 cyfra)*/
             sprintf(tablica,"%i",wynikADC);/*alternatywa dla znanej z Atmeg funkcji itoa, konwertuj z int na char*/
             WyswietlLCD(tablica); /*wyswietlamy czesc ulamkowa temperatury*/
             WyswietlLCD("\x01""C"); /*wyswietlamy zdefiniowany znak stC, po \ podajemy kod ASCII nowego znaku*/
              }   
            }
            
    }
    return 0;
}


void Set_MCP3424(void)
{
  
    i2c_start(); 
  
   /*MCP3421 ADDRESS BYTE - MSB first*/
  
   /* 1 - 1 - 0 - 1 - A2 - A1 - A0 - R/W*/
    
   i2c_write(0b11010000); /*wysylamy bajt z adresem MCP3424 R/W - 0*/
   __delay_us(10); /*zwloka na ustawienie ACK przez MCP3424*/
   
   /*MCP3421 CONFIGURATION REGISTER - MSB first*/
   /*RDY - C1 - C0 - O/C - S1 - S0 - G1 - G0*/
   /*RDY - ready bit,
     C1-C0 - channel selection bit
     O/C - conversion mode bit
     S1-S0 - sample rate
     G1-G0 - PGA gain selection*/
   i2c_write(0b00011000); /*wysylamy bajt konfiguracyjny Continuous conversion - 16bit - channel 0 - PGA = 1*/
   __delay_us(10); /*zwloka na ustawienie ACK przez MCP3424*/
   i2c_stop(); 
}

/*funkcja odczytu danych z MCP3424*/
int read_MCP3424(void)
{
   uint16_t readADC=0;
         
   i2c_start(); 
   i2c_write(0b11010001);/*wysylamy bajt z adresem MCP3424 R/W - 1*/
    __delay_us(10); /*zwloka na ustawienie ACK przez MCP3424*/
   readADC=i2c_read(); /*odczytujemy starszy bajt z danymi*/
   i2c_ack();
   readADC<<=8; /*przesuwamy odebrany bajt na pozycje starszego bajtu w slowie 16 bitowym*/
   readADC+=i2c_read(); /*odczytujemy mlodszy bajt z danymi i sumujemy go z poprzednia wartoscia*/
   /*konczymy odczyt, pomijamy odczyt bajtu konfiguracyjnego*/
   i2c_nack();
   i2c_stop(); 
      
   return(readADC);
}

/*Inicjacja/konfiguracja Timera1*/
void InitTimer1(void){
    /*konfiguracja Timer1*/
    T1CONbits.TON = 0 ; /*Stop the timer1*/
    TMR1 = 0x0000 ;/*Clear timer register*/
    /*Zegar ok 40 MHz(39.61375 MHz) Prescaler 1:64; PR1 Preload = 61897; Actual Interrupt Time = 100 ms*/
    T1CONbits.TCKPS = 0b10 ; /*Prescaler 1:64*/
   
    /*konfiguracja przerwania*/
    IFS0bits.T1IF	 = 0; /*Clear Timer1 Interrupt Flag*/
    IEC0bits.T1IE	 = 1; /*Enable Timer1 Interrupt*/
    
    /*ustaw priorytet dla przerwania*/
    IPC0bits.T1IP = 0b100 ; /*Set Timer1 Interrupt Prioryty Level 4*/

/*TMR1 zlicza do wartosci ustawionej w PR1 jesli TMR1=PR1 zglaszane jest przerwanie*/
/*40MHz / Prescaler / PR1*/

 /*ok.10Hz (100ms*/    
 //PR1		 = 61897; /*Load period value*/
 //T1CONbits.TON = 1 ; /*Start the timer1*/    
  
 /*ok.100Hz (10ms)*/    
   PR1		 = 6189; /*Load period value*/
   T1CONbits.TON = 1 ; /*Start the timer1*/  
}

/*Obsluga wektora przerwania dla Timer1*/
void __attribute__((interrupt, no_auto_psv))_T1Interrupt(void)
{
/*kod uzytkownika do obslugi przerwania*/
    uint8_t x;
    x = Timer1_Programowy ;
    if (x) Timer1_Programowy = --x ;
    x = Timer2_Programowy ;
    if (x) Timer2_Programowy = --x ;

    /* Clear Timer1 interrupt */
IFS0bits.T1IF = 0 ; /*Clear Timer1 Interrupt Flag*/
}